
import type { Section } from "../sections/sectionTypes.js";

export interface Match {
  oldId: string;
  newId: string;
  oldTitle: string;
  newTitle: string;
  score: number; // 0..1
  reason: "numbering" | "fuzzy";
}

export interface SectionMap {
  matched: Match[];
  added: { id: string; title: string }[];
  removed: { id: string; title: string }[];
}

/** Extract leading numbering key like "1", "2.3", "4.1.2" */
function getNumberingKey(title: string): string | null {
  const t = title.trim();
  const m = t.match(/^(\d+(?:\.\d+)*)\./);      // "1." or "2.3."
  if (m) return m[1];
  const m2 = t.match(/^(\d+(?:\.\d+)*)\s+/);    // "1 Something" (no dot)
  if (m2) return m2[1];
  return null;
}

function normalizeTitle(s: string): string {
  return s
    .toLowerCase()
    .replace(/[`'"]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenize(s: string): string[] {
  return normalizeTitle(s).split(" ").filter(w => w.length > 1);
}

/** Jaccard similarity between token sets */
function jaccard(a: string[], b: string[]): number {
  const A = new Set(a);
  const B = new Set(b);
  const inter = [...A].filter(x => B.has(x)).length;
  const union = new Set([...A, ...B]).size;
  return union === 0 ? 0 : inter / union;
}

/** Dice coefficient over bigrams for character-level similarity */
function diceCoefficient(a: string, b: string): number {
  const s1 = normalizeTitle(a);
  const s2 = normalizeTitle(b);
  if (s1.length < 2 || s2.length < 2) return 0;

  const bigrams = (s: string) => {
    const out: string[] = [];
    for (let i = 0; i < s.length - 1; i++) out.push(s.slice(i, i + 2));
    return out;
  };

  const b1 = bigrams(s1);
  const b2 = bigrams(s2);
  const map = new Map<string, number>();
  for (const x of b1) map.set(x, (map.get(x) ?? 0) + 1);

  let matches = 0;
  for (const x of b2) {
    const c = map.get(x) ?? 0;
    if (c > 0) {
      matches++;
      map.set(x, c - 1);
    }
  }

  return (2 * matches) / (b1.length + b2.length);
}

function combinedScore(oldTitle: string, newTitle: string): number {
  const tokA = tokenize(oldTitle);
  const tokB = tokenize(newTitle);
  const sJ = jaccard(tokA, tokB);
  const sD = diceCoefficient(oldTitle, newTitle);
  // weighted blend
  return 0.6 * sJ + 0.4 * sD;
}

/**
 * Align sections old ↔ new:
 * 1) Match by numbering key (strong match)
 * 2) Fuzzy match remaining by title similarity
 */
export function alignSections(oldSecs: Section[], newSecs: Section[], threshold = 0.65): SectionMap {
  const matched: Match[] = [];
  const usedNew = new Set<string>();
  const usedOld = new Set<string>();

  // --- Pass 1: numbering match ---
  const newByNum = new Map<string, Section>();
  for (const ns of newSecs) {
    const key = getNumberingKey(ns.title);
    if (key) newByNum.set(key, ns);
  }

  for (const os of oldSecs) {
    const key = getNumberingKey(os.title);
    if (!key) continue;
    const candidate = newByNum.get(key);
    if (candidate) {
      matched.push({
        oldId: os.id,
        newId: candidate.id,
        oldTitle: os.title,
        newTitle: candidate.title,
        score: 1.0,
        reason: "numbering"
      });
      usedOld.add(os.id);
      usedNew.add(candidate.id);
    }
  }

  // --- Pass 2: fuzzy match for remaining ---
  const remainingOld = oldSecs.filter(s => !usedOld.has(s.id));
  const remainingNew = newSecs.filter(s => !usedNew.has(s.id));

  for (const os of remainingOld) {
    let best: { sec: Section; score: number } | null = null;

    for (const ns of remainingNew) {
      if (usedNew.has(ns.id)) continue;
      const score = combinedScore(os.title, ns.title);
      if (!best || score > best.score) best = { sec: ns, score };
    }

    if (best && best.score >= threshold) {
      matched.push({
        oldId: os.id,
        newId: best.sec.id,
        oldTitle: os.title,
        newTitle: best.sec.title,
        score: Number(best.score.toFixed(3)),
        reason: "fuzzy"
      });
      usedOld.add(os.id);
      usedNew.add(best.sec.id);
    }
  }

  // Added/Removed
  const added = newSecs
    .filter(s => !usedNew.has(s.id))
    .map(s => ({ id: s.id, title: s.title }));

  const removed = oldSecs
    .filter(s => !usedOld.has(s.id))
    .map(s => ({ id: s.id, title: s.title }));

  return { matched, added, removed };
}
``
