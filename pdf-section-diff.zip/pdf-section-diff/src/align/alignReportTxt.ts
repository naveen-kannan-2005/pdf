
import type { SectionMap } from "./sectionAligner.js";

export function buildAlignmentTxt(map: SectionMap, oldPdf: string, newPdf: string) {
  const out: string[] = [];

  out.push("========================================");
  out.push("SECTION ALIGNMENT REPORT (STEP 3)");
  out.push("========================================");
  out.push(`Old PDF: ${oldPdf}`);
  out.push(`New PDF: ${newPdf}`);
  out.push("");
  out.push(`Matched : ${map.matched.length}`);
  out.push(`Added   : ${map.added.length}`);
  out.push(`Removed : ${map.removed.length}`);
  out.push("");

  out.push("------------ MATCHED SECTIONS -----------");
  for (const m of map.matched) {
    out.push(`- [${m.reason}] score=${m.score}`);
    out.push(`  OLD: (${m.oldId}) ${m.oldTitle}`);
    out.push(`  NEW: (${m.newId}) ${m.newTitle}`);
    out.push("");
  }

  out.push("-------------- ADDED (NEW) --------------");
  for (const a of map.added) {
    out.push(`+ (${a.id}) ${a.title}`);
  }
  out.push("");

  out.push("------------- REMOVED (OLD) -------------");
  for (const r of map.removed) {
    out.push(`- (${r.id}) ${r.title}`);
  }
  out.push("");

  out.push("========================================");
  out.push("END OF REPORT");
  out.push("========================================");

  return out.join("\n");
}
