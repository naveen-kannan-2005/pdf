
import type { Section } from "./sectionTypes.js";

export function buildSectionsTxt(
  sections: Section[],
  pdfPath: string,
  selectedRunId: string
) {
  const out: string[] = [];

  out.push("========================================");
  out.push("PDF SECTIONS REPORT (STEP 2)");
  out.push("========================================");
  out.push(`PDF File     : ${pdfPath}`);
  out.push(`Run Selected : ${selectedRunId}`);
  out.push(`Sections     : ${sections.length}`);
  out.push("");

  for (const s of sections) {
    out.push("----------------------------------------");
    out.push(`ID         : ${s.id}`);
    out.push(`Title      : ${s.title}`);
    out.push(`Level      : ${s.level}`);
    out.push(`Source     : ${s.source}`);
    out.push(`Confidence : ${s.confidence.toFixed(2)}`);
    out.push(
      `Span       : Page ${s.span.startPage}:${s.span.startLine} -> Page ${s.span.endPage}:${s.span.endLine}`
    );
    out.push(`Pages      : ${s.pageCount}`);
    out.push(`Preview    : ${s.preview ?? "(none)"}`);
    out.push("");
  }

  out.push("========================================");
  out.push("END OF REPORT");
  out.push("========================================");

  return out.join("\n");
}
