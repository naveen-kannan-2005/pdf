
import type { PdfPageData } from "../extract/types.js";
import type { Section } from "./sectionTypes.js";

type Hit = {
  pageNumber: number;
  lineIndex: number;
  title: string;
  level: number;
  idBase: string;
  confidence: number;
  source: Section["source"];
};

function slugify(s: string) {
  return s.toLowerCase().replace(/[`'"]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

// Generic “noise” headings commonly found in procedure documents
const NOISE_LINE = /^(accomplished by|partial sign off status|step:|completed through:|accomp by:|check box|end of work steps)/i;

// Sub-step markers: "A.", "B.", "(1)", "(a)" etc. These are NOT top-level sections.
const SUBSTEP = /^([A-Z]\.|[\(\[]\d+[\)\]]|[\(\[]?[a-z][\)\]]?)\s+/;

// Strong top-level patterns
const STEP_HEADING = /^(\d+)\.\s+(.+)$/;                  // 1. Something
const FIGURE_HEADING = /^_?Figure\s+(\d+)\s*[:\-]?\s*(.+)?_?$/i;
const COLON_HEADING = /^[A-Z][A-Za-z0-9 /()\-]{2,60}:\s*$/; // "Something:"

// Exclude form-like lines (many underscores)
function hasManyUnderscores(s: string) {
  const underscores = (s.match(/_/g) ?? []).length;
  return underscores >= 3;
}

function detectTopLevelHeading(line: string): Omit<Hit, "pageNumber" | "lineIndex"> | null {
  const l = line.trim();
  if (!l) return null;

  if (NOISE_LINE.test(l)) return null;
  if (SUBSTEP.test(l)) return null;
  if (hasManyUnderscores(l)) return null;

  // 1) Numbered steps (strongest)
  const step = l.match(STEP_HEADING);
  if (step) {
    const n = step[1];
    const title = `${n}. ${step[2].trim()}`;
    return { title, level: 1, idBase: `step-${n}`, confidence: 0.98, source: "regex" };
  }

  // 2) Figures
  const fig = l.replace(/^_+|_+$/g, "").match(FIGURE_HEADING);
  if (fig) {
    const n = fig[1];
    const rest = (fig[2] ?? "").trim();
    const title = rest ? `Figure ${n}: ${rest}` : `Figure ${n}`;
    return { title, level: 1, idBase: `figure-${n}`, confidence: 0.90, source: "regex" };
  }

  // 3) Short "X:" headings (generic)
  if (COLON_HEADING.test(l)) {
    const title = l.trim();
    return { title, level: 1, idBase: `sec-${slugify(title)}`, confidence: 0.70, source: "heuristic" };
  }

  // 4) "Procedures Section" / "Something Section" (generic)
  if (/^[A-Z][A-Za-z0-9 /()\-]{2,60}\s+Section$/i.test(l)) {
    return { title: l, level: 1, idBase: `sec-${slugify(l)}`, confidence: 0.65, source: "heuristic" };
  }

  return null;
}

export function extractSections(pages: PdfPageData[]): Section[] {
  const hits: Hit[] = [];

  for (const p of pages) {
    for (let i = 0; i < p.lines.length; i++) {
      const h = detectTopLevelHeading(p.lines[i]);
      if (h) hits.push({ pageNumber: p.pageNumber, lineIndex: i, ...h });
    }
  }

  // If nothing found, return whole document as one section
  if (hits.length === 0) {
    const start = pages[0]?.pageNumber ?? 1;
    const end = pages.at(-1)?.pageNumber ?? start;
    const endLine = Math.max(0, (pages.at(-1)?.lines.length ?? 1) - 1);

    return [{
      id: "sec-document",
      title: "Document",
      level: 1,
      span: { startPage: start, startLine: 0, endPage: end, endLine },
      source: "heuristic",
      confidence: 0.2,
      pageCount: Math.max(1, end - start + 1),
      preview: pages[0]?.lines.slice(0, 3).join(" ") ?? ""
    }];
  }

  // Sort hits in reading order
  hits.sort((a, b) => a.pageNumber - b.pageNumber || a.lineIndex - b.lineIndex);

  // Unique IDs if duplicates
  const seen = new Map<string, number>();
  const uniq = (base: string) => {
    const n = (seen.get(base) ?? 0) + 1;
    seen.set(base, n);
    return n === 1 ? base : `${base}-${n}`;
  };

  const sections: Section[] = [];

  for (let idx = 0; idx < hits.length; idx++) {
    const cur = hits[idx];
    const next = hits[idx + 1];

    const startPage = cur.pageNumber;
    const startLine = cur.lineIndex;

    let endPage: number;
    let endLine: number;

    if (next) {
      endPage = next.pageNumber;
      endLine = next.lineIndex - 1;

      if (endLine < 0) {
        // end at previous page end
        const prev = pages.find(p => p.pageNumber === endPage - 1);
        endPage = endPage - 1;
        endLine = prev ? prev.lines.length - 1 : 0;
      }
    } else {
      const last = pages.at(-1)!;
      endPage = last.pageNumber;
      endLine = Math.max(0, last.lines.length - 1);
    }

    const pageCount = Math.max(1, endPage - startPage + 1);

    const curPage = pages.find(p => p.pageNumber === startPage);
    const preview = curPage ? curPage.lines.slice(startLine + 1, startLine + 4).join(" ") : "";

    sections.push({
      id: uniq(cur.idBase),
      title: cur.title,
      level: cur.level,
      span: { startPage, startLine, endPage, endLine },
      source: cur.source,
      confidence: cur.confidence,
      pageCount,
      preview: preview || undefined
    });
  }

  return sections;
}
``
