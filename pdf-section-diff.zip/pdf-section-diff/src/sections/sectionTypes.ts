
export type SectionSource =
  | "toc"        // extracted from Table of Contents if present (future)
  | "heuristic"  // detected by generic heuristics
  | "regex"      // detected via numbering patterns (1, 1.1, 2.3.4)
  | "manual";    // optional in future

export interface SectionSpan {
  startPage: number;
  startLine: number; // index within PdfPageData.lines
  endPage: number;
  endLine: number;   // index within PdfPageData.lines
}

export interface Section {
  id: string;            // stable identifier (best effort)
  title: string;         // heading text
  level: number;         // 1 = top-level, 2 = sub, etc.
  span: SectionSpan;     // where it starts/ends
  source: SectionSource; // detection method
  confidence: number;    // 0..1
  pageCount: number;     // computed convenience field
  preview?: string;      // a short snippet from content
}
