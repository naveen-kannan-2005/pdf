
import type { PdfLink } from "../extract/types.js";
import { normalizeLink } from "./linkSlice.js";

export interface LinkDiffResult {
  added: string[];
  removed: string[];
}

export function diffLinks(oldLinks: PdfLink[], newLinks: PdfLink[]): LinkDiffResult {
  const oldSet = new Set(oldLinks.map(normalizeLink));
  const newSet = new Set(newLinks.map(normalizeLink));

  const added = [...newSet].filter(x => !oldSet.has(x)).sort();
  const removed = [...oldSet].filter(x => !newSet.has(x)).sort();

  return { added, removed };
}
