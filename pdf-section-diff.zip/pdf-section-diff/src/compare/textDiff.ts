
import { diffLines } from "diff";

export interface DiffOnly {
  added: string[];
  removed: string[];
  modified: { from: string; to: string; score: number }[];
}

/** Normalize for matching / comparing */
function norm(s: string): string {
  return s
    .toLowerCase()
    .replace(/[`'"]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Dice coefficient on bigrams for similarity */
function dice(a: string, b: string): number {
  const s1 = norm(a);
  const s2 = norm(b);
  if (s1.length < 2 || s2.length < 2) return 0;

  const bigrams = (s: string) => {
    const out: string[] = [];
    for (let i = 0; i < s.length - 1; i++) out.push(s.slice(i, i + 2));
    return out;
  };

  const b1 = bigrams(s1);
  const b2 = bigrams(s2);
  const map = new Map<string, number>();
  for (const x of b1) map.set(x, (map.get(x) ?? 0) + 1);

  let matches = 0;
  for (const x of b2) {
    const c = map.get(x) ?? 0;
    if (c > 0) {
      matches++;
      map.set(x, c - 1);
    }
  }
  return (2 * matches) / (b1.length + b2.length);
}

/**
 * Create "diff-only" output: added[], removed[], modified[]
 * modified is formed by pairing removed+added lines when similar.
 */
export function diffOnly(oldText: string, newText: string, modifyThreshold = 0.72): DiffOnly {
  const changes = diffLines(oldText ?? "", newText ?? "");

  const added: string[] = [];
  const removed: string[] = [];

  for (const part of changes) {
    const lines = (part.value ?? "").split("\n").map(l => l.trim()).filter(Boolean);

    if (part.added) added.push(...lines);
    else if (part.removed) removed.push(...lines);
  }

  // Build modified pairs by greedy matching: each removed line can match one added line
  const usedAdded = new Set<number>();
  const modified: { from: string; to: string; score: number }[] = [];

  for (let i = 0; i < removed.length; i++) {
    let bestJ = -1;
    let bestScore = 0;

    for (let j = 0; j < added.length; j++) {
      if (usedAdded.has(j)) continue;
      const s = dice(removed[i], added[j]);
      if (s > bestScore) {
        bestScore = s;
        bestJ = j;
      }
    }

    if (bestJ !== -1 && bestScore >= modifyThreshold) {
      modified.push({ from: removed[i], to: added[bestJ], score: Number(bestScore.toFixed(2)) });
      usedAdded.add(bestJ);
      // mark removed as consumed by modified by replacing with empty marker
      removed[i] = "";
    }
  }

  const finalRemoved = removed.filter(Boolean);
  const finalAdded = added.filter((_, idx) => !usedAdded.has(idx));

  return {
    added: finalAdded,
    removed: finalRemoved,
    modified
  };
}
