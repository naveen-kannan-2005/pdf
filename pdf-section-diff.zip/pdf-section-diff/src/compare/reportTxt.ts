
import type { SectionComparison } from "./compareSections.js";
import type { SectionMap } from "../align/sectionAligner.js";

export function buildDiffOnlyTxt(
  comps: SectionComparison[],
  map: SectionMap,
  oldPdf: string,
  newPdf: string
): string {
  const changed = comps.filter(c => c.changed);

  const out: string[] = [];
  out.push("========================================");
  out.push("DIFF-ONLY REPORT (TEXT + LINKS)");
  out.push("========================================");
  out.push(`Old PDF: ${oldPdf}`);
  out.push(`New PDF: ${newPdf}`);
  out.push("");
  out.push(`Matched sections compared : ${comps.length}`);
  out.push(`Changed sections          : ${changed.length}`);
  out.push(`Added sections (new only) : ${map.added.length}`);
  out.push(`Removed sections (old only): ${map.removed.length}`);
  out.push("");

  // Added/Removed sections
  out.push("-------------- ADDED SECTIONS (NEW) --------------");
  if (map.added.length === 0) out.push("(none)");
  for (const a of map.added) out.push(`+ ${a.title}`);
  out.push("");

  out.push("------------- REMOVED SECTIONS (OLD) -------------");
  if (map.removed.length === 0) out.push("(none)");
  for (const r of map.removed) out.push(`- ${r.title}`);
  out.push("");

  out.push("------------ SECTION DIFFS (ONLY CHANGES) --------");
  for (const c of changed) {
    out.push("----------------------------------------");
    out.push(`SECTION [${c.match.reason}] score=${c.match.score}`);
    out.push(`OLD: ${c.match.oldTitle}`);
    out.push(`NEW: ${c.match.newTitle}`);
    out.push("");

    // Links
    if (c.links.added.length || c.links.removed.length) {
      out.push("LINKS:");
      if (c.links.added.length) {
        out.push("  ADDED:");
        for (const a of c.links.added) out.push(`    + ${a}`);
      }
      if (c.links.removed.length) {
        out.push("  REMOVED:");
        for (const r of c.links.removed) out.push(`    - ${r}`);
      }
      out.push("");
    }

    // Text
    if (c.text.modified.length || c.text.added.length || c.text.removed.length) {
      out.push("TEXT:");
      if (c.text.modified.length) {
        out.push("  MODIFIED:");
        for (const m of c.text.modified) {
          out.push(`    ~ (${m.score})`);
          out.push(`      - ${m.from}`);
          out.push(`      + ${m.to}`);
        }
      }
      if (c.text.added.length) {
        out.push("  ADDED:");
        for (const a of c.text.added) out.push(`    + ${a}`);
      }
      if (c.text.removed.length) {
        out.push("  REMOVED:");
        for (const r of c.text.removed) out.push(`    - ${r}`);
      }
      out.push("");
    }
  }

  out.push("========================================");
  out.push("END OF REPORT");
  out.push("========================================");

  return out.join("\n");
}
``
