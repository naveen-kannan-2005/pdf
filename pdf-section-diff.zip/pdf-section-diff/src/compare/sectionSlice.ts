
import type { PdfPageData } from "../extract/types.js";
import type { Section } from "../sections/sectionTypes.js";

export interface SectionContent {
  sectionId: string;
  title: string;
  pageStart: number;
  pageEnd: number;
  lines: string[];
  text: string;
}

const NOISE_PATTERNS: RegExp[] = [
  /^printed on\s+/i,
  /^station:\s*/i,
  /^a\/c:\s*/i,
  /^revision date:\s*/i,
  /^check:\s*/i,
  /^board copy/i,
  /^page\s+\d+\s+of\s+\d+/i,
  /^utc\s*-\s*/i,

  // Very common repeated header line in your PDFs
  /^emergency equipment installation$/i,

  // Workcard boilerplate noise (optional but recommended)
  /^partial sign off status/i,
  /^step:\s*/i,
  /^completed through:/i,
  /^accomp by:/i,
  /^accomplished by$/i,
  /^o\s*check box/i,
];

function normalizeLine(s: string): string {
  return s.replace(/\s+/g, " ").trim();
}

function isNoise(line: string): boolean {
  const l = normalizeLine(line);
  if (!l) return true;
  return NOISE_PATTERNS.some(rx => rx.test(l));
}

export function sliceSectionContent(pages: PdfPageData[], section: Section): SectionContent {
  const { startPage, startLine, endPage, endLine } = section.span;

  const collected: string[] = [];

  for (const p of pages) {
    if (p.pageNumber < startPage || p.pageNumber > endPage) continue;

    let from = 0;
    let to = p.lines.length - 1;

    // skip heading line itself
    if (p.pageNumber === startPage) from = Math.max(0, startLine + 1);
    if (p.pageNumber === endPage) to = Math.min(p.lines.length - 1, endLine);

    if (to >= from) {
      collected.push(...p.lines.slice(from, to + 1));
    }
  }

  // ✅ Noise filtering for "exact" output
  const filtered = collected
    .map(normalizeLine)
    .filter(l => !isNoise(l));

  const text = filtered.join("\n").trim();

  return {
    sectionId: section.id,
    title: section.title,
    pageStart: startPage,
    pageEnd: endPage,
    lines: filtered,
    text
  };
}
