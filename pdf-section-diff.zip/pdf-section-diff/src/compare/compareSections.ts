
import type { Section } from "../sections/sectionTypes.js";
import type { PdfPageData } from "../extract/types.js";
import type { Match } from "../align/sectionAligner.js";

import { sliceSectionContent } from "./sectionSlice.js";
import { sliceSectionLinks } from "./linkSlice.js";
import { diffLinks } from "./linkDiff.js";
import { diffOnly } from "./textDiff.js";

export interface SectionComparison {
  match: Match;
  text: {
    added: string[];
    removed: string[];
    modified: { from: string; to: string; score: number }[];
  };
  links: { added: string[]; removed: string[] };
  changed: boolean;
}

export function compareMatchedSections(
  matches: Match[],
  oldSections: Section[],
  newSections: Section[],
  oldPages: PdfPageData[],
  newPages: PdfPageData[]
): SectionComparison[] {
  const oldById = new Map(oldSections.map(s => [s.id, s]));
  const newById = new Map(newSections.map(s => [s.id, s]));

  const results: SectionComparison[] = [];

  for (const m of matches) {
    const os = oldById.get(m.oldId);
    const ns = newById.get(m.newId);
    if (!os || !ns) continue;

    const oldContent = sliceSectionContent(oldPages, os);
    const newContent = sliceSectionContent(newPages, ns);

    const oldLinks = sliceSectionLinks(oldPages, os);
    const newLinks = sliceSectionLinks(newPages, ns);

    const text = diffOnly(oldContent.text, newContent.text);
    const links = diffLinks(oldLinks, newLinks);

    const changed =
      text.added.length > 0 ||
      text.removed.length > 0 ||
      text.modified.length > 0 ||
      links.added.length > 0 ||
      links.removed.length > 0;

    results.push({ match: m, text, links, changed });
  }

  return results;
}
