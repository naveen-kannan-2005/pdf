
import type { PdfPageData, PdfLink } from "../extract/types.js";
import type { Section } from "../sections/sectionTypes.js";

export function sliceSectionLinks(pages: PdfPageData[], section: Section): PdfLink[] {
  const { startPage, endPage } = section.span;
  const links: PdfLink[] = [];

  for (const p of pages) {
    if (p.pageNumber < startPage || p.pageNumber > endPage) continue;
    links.push(...(p.links ?? []));
  }
  return links;
}

export function normalizeLink(l: PdfLink): string {
  if (l.kind === "external") {
    const url = (l.url ?? "").trim();
    return `external:${url}`;
  }

  // internal: normalize destination into stable string
  // PDF.js can return dest as string, array, or object
  let destStr = "";
  try {
    if (typeof l.dest === "string") destStr = l.dest;
    else destStr = JSON.stringify(l.dest);
  } catch {
    destStr = String(l.dest);
  }
  return `internal:${destStr}`;
}
