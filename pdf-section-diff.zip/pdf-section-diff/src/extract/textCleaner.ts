
const DROP_LINE_PATTERNS: RegExp[] = [
  /^Printed on\s+/i,
  /^Station:\s*/i,
  /^A\/C:\s*/i,
  /^Revision Date:\s*/i,
  /^Check:\s*/i,
  /^BOARD COPY$/i,
  /^Board Copy Page\s+\d+\s+of\s+\d+/i,
  /^Page\s+\d+\s+of\s+\d+/i
];

export function normalizeSpaces(s: string) {
  return s.replace(/\s+/g, " ").trim();
}

export function cleanToLines(raw: string): string[] {
  const lines = raw
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(Boolean);

  const kept: string[] = [];
  for (const line of lines) {
    const drop = DROP_LINE_PATTERNS.some(rx => rx.test(line));
    if (!drop) kept.push(normalizeSpaces(line));
  }
  return kept;
}

export function cleanPageText(raw: string): string {
  return cleanToLines(raw).join("\n");
}
