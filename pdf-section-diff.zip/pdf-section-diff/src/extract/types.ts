
export type LinkKind = "external" | "internal";

export interface PdfLink {
  kind: LinkKind;
  url?: string;
  dest?: unknown;
  rect?: [number, number, number, number];
}


export interface PdfPageData {
  pageNumber: number;
  text: string;
  lines: string[];  // ✅ REQUIRED for section detection
  links: PdfLink[];
  footerHint?: string;
}


export interface PdfRun {
  runId: string;
  pages: number[];
}

export interface ExtractedPdf {
  meta: { totalPages: number };
  runs: PdfRun[];
  selectedRunId: string;
  pages: PdfPageData[];
}
``
