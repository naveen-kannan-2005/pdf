
import { PdfPageData, PdfRun } from "./types.js";

export function detectRuns(allPages: PdfPageData[]) {
  const boardCopyPages: number[] = [];
  const fullRunsMap = new Map<string, number[]>(); // runId => pages

  for (const p of allPages) {
    const hint = p.footerHint ?? "";

    const bc = hint.match(/Board Copy Page\s+(\d+)\s+of\s+(\d+)/i);
    if (bc) {
      boardCopyPages.push(p.pageNumber);
      continue;
    }

    const full = hint.match(/Page\s+(\d+)\s+of\s+(\d+)/i);
    if (full) {
      const total = full[2];
      const runId = `full:${total}`;
      if (!fullRunsMap.has(runId)) fullRunsMap.set(runId, []);
      fullRunsMap.get(runId)!.push(p.pageNumber);
    }
  }

  const runs: PdfRun[] = [];
  if (boardCopyPages.length) runs.push({ runId: "boardCopy", pages: boardCopyPages });

  for (const [runId, pages] of fullRunsMap.entries()) {
    pages.sort((a, b) => a - b);
    runs.push({ runId, pages });
  }

  // Choose canonical run: prefer largest full:N
  const fullCandidates = runs
    .filter(r => r.runId.startsWith("full:"))
    .map(r => ({ r, total: Number(r.runId.split(":")[1]) }))
    .sort((a, b) => b.total - a.total);

  let selectedRunId = "unknown";
  let selectedPages = allPages;

  if (fullCandidates.length) {
    const best = fullCandidates[0].r;
    selectedRunId = best.runId;
    const set = new Set(best.pages);
    selectedPages = allPages.filter(p => set.has(p.pageNumber));
  } else if (boardCopyPages.length) {
    selectedRunId = "boardCopy";
    const set = new Set(boardCopyPages);
    selectedPages = allPages.filter(p => set.has(p.pageNumber));
  }

  return { runs, selectedRunId, selectedPages };
}
