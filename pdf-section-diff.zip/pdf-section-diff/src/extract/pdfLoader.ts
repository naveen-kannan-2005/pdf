
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { createRequire } from "node:module";

// Legacy build import (ESM .mjs) is a common working approach. [5](https://github.com/mozilla/pdf.js/discussions/18300)
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.mjs";

const require = createRequire(import.meta.url);

// ✅ Set workerSrc in a supported way (avoids “No GlobalWorkerOptions.workerSrc specified” issues).
// Worker configuration is part of official integration guidance. [3](https://github.com/mozilla/pdf.js/discussions/17622)[4](https://stackoverflow.com/questions/79044550/how-to-use-pdfjs-worker-in-react-and-typescript)
const workerPath = require.resolve("pdfjs-dist/legacy/build/pdf.worker.mjs");
(pdfjsLib as any).GlobalWorkerOptions.workerSrc = pathToFileURL(workerPath).toString();

export async function loadPdf(filePath: string) {
  const abs = path.resolve(filePath);
  const data = new Uint8Array(fs.readFileSync(abs));

  // ✅ Supported API usage: pass DocumentInitParameters (data/url/etc).
  // "disableWorker" is not part of the documented init params list. [1](https://mozilla.github.io/pdf.js/api/draft/module-pdfjsLib.html)[2](https://deepwiki.com/mozilla/pdf.js/3.1-public-api-and-document-loading)
  const loadingTask = (pdfjsLib as any).getDocument({ data });

  return loadingTask.promise;
}
