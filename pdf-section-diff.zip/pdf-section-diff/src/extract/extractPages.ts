
import type { PdfPageData, PdfLink } from "./types.js";
import { cleanToLines, normalizeSpaces } from "./textCleaner.js";
import { buildLinesFromTextItems } from "./lineBuilder.js";

function getFooterHint(fullText: string): string | undefined {
  return (
    fullText.match(/Board Copy Page\s+\d+\s+of\s+\d+/i)?.[0] ??
    fullText.match(/Page\s+\d+\s+of\s+\d+/i)?.[0]
  );
}

export async function extractPages(pdf: any): Promise<PdfPageData[]> {
  const pages: PdfPageData[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);

    const textContent = await page.getTextContent({ disableCombineTextItems: false });

    // ✅ Build real lines (instead of token-per-line)
    const rawLines = buildLinesFromTextItems(textContent.items ?? []);
    const raw = rawLines.join("\n");

    const footerHint = getFooterHint(raw);

    // Clean lines (remove header/footer noise)
    const lines = cleanToLines(raw);
    const text = normalizeSpaces(lines.join("\n"));

    // Links
    const annots = await page.getAnnotations();
    const links: PdfLink[] = (annots ?? [])
      .filter((a: any) => a.subtype === "Link")
      .map((a: any) => {
        if (a.url) return { kind: "external", url: a.url, rect: a.rect };
        if (a.dest) return { kind: "internal", dest: a.dest, rect: a.rect };
        return null;
      })
      .filter((x: any): x is PdfLink => x !== null);

    pages.push({ pageNumber: i, text, lines, links, footerHint });
  }

  return pages;
}
