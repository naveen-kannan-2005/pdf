
export interface TextItemLike {
  str?: string;
  transform?: number[]; // [a,b,c,d,e,f] where e=x, f=y
  width?: number;
}

export function buildLinesFromTextItems(items: TextItemLike[], yTolerance = 2): string[] {type LineToken = { x: number; y: number; text: string };
  const tokens: LineToken[] = [];

  for (const it of items) {
    const text = (it.str ?? "").trim();
    if (!text) continue;
    const tr = it.transform;
    if (!tr || tr.length < 6) continue;

    const x = tr[4];
    const y = tr[5];
    tokens.push({ x, y, text });
  }

  // Group by rounded Y
  const groups = new Map<number, LineToken[]>();
  for (const t of tokens) {
    const yKey = Math.round(t.y / yTolerance) * yTolerance;
    if (!groups.has(yKey)) groups.set(yKey, []);
    groups.get(yKey)!.push(t);
  }

  // Sort Y descending (top to bottom)
  const ys = [...groups.keys()].sort((a, b) => b - a);

  const lines: string[] = [];
  for (const y of ys) {
    const row = groups.get(y)!;
    // Sort by X ascending (left to right)
    row.sort((a, b) => a.x - b.x);

    // Join tokens with spaces
    const line = row.map(r => r.text).join(" ").replace(/\s+/g, " ").trim();
    if (line) lines.push(line);
  }

  return lines;
}


