
import fs from "node:fs";
import path from "node:path";

import { loadPdf } from "./pdfLoader.js";
import { extractPages } from "./extractPages.js";
import { detectRuns } from "./runDetector.js";

import { extractSections } from "../sections/sectionExtractor.js";

import { alignSections } from "../align/sectionAligner.js";
import { compareMatchedSections } from "../compare/compareSections.js";

import { buildDiffOnlyTxt } from "../compare/reportTxt.js";



const OLD_PDF_PATH = "C:/Users/NKPeriyachi/Downloads/Workcard-preview-26T22052001.pdf";
const NEW_PDF_PATH = "C:/Users/NKPeriyachi/Downloads/Workcard-preview-2516B910-006 (1).pdf";
const OUT_DIR = "out";

async function extractCanonical(pdfPath: string) {
  const pdf = await loadPdf(pdfPath);
  const allPages = await extractPages(pdf);
  const { selectedRunId, selectedPages } = detectRuns(allPages);
  return { selectedRunId, pages: selectedPages };
}

async function main() {
  fs.mkdirSync(path.resolve(OUT_DIR), { recursive: true });

  // Load old/new canonical pages
  const oldDoc = await extractCanonical(OLD_PDF_PATH);
  const newDoc = await extractCanonical(NEW_PDF_PATH);

  // Extract sections
  const oldSections = extractSections(oldDoc.pages);
  const newSections = extractSections(newDoc.pages);

  // Align sections
  const map = alignSections(oldSections, newSections, 0.65);

  // Compare content in matched sections
  const comps = compareMatchedSections(
    map.matched,
    oldSections,
    newSections,
    oldDoc.pages,
    newDoc.pages
  );

  // Write TXT report
  
const report = buildDiffOnlyTxt(comps, map, OLD_PDF_PATH, NEW_PDF_PATH);
fs.writeFileSync(path.join(OUT_DIR, "diff-only.txt"), report, "utf-8");

  console.log("✅ Step 4 complete:");
  console.log(`   out\\section-diff.txt`);
}

main().catch(err => {
  console.error("❌ Error:", err);
  process.exit(1);
});
