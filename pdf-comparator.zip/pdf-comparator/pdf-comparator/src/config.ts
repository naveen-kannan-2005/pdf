import fs from 'fs';
import yaml from 'js-yaml';
 
export interface Config {
  oldPath: string;
  newPath: string;
  outputPath?: string;
  enableOCR?: boolean;
}
 
export function loadConfig(path: string): Config {
  const content = fs.readFileSync(path, 'utf8');
  return yaml.load(content) as Config;
}