import { NormalizedPage } from './normalize';
 
export interface Section {
  id: string;
  title: string;
  pageNum: number;
  lines: string[];
}
 
export function segmentDocument(pages: NormalizedPage[]): Section[] {
  const sections: Section[] = [];
  let current: Section | null = null;
 
  for (const page of pages) {
    for (const line of page.lines) {
      const stepMatch = line.match(/^(\d+)\.\s+(.*)$/); // e.g., 1. Title
 
      if (stepMatch) {
        if (current) sections.push(current);
        current = {
          id: stepMatch[1],
          title: stepMatch[2],
          pageNum: page.pageNum,
          lines: []
        };
      } else if (current) {
        current.lines.push(line);
      }
    }
  }
 
  if (current) sections.push(current);
  return sections;
}