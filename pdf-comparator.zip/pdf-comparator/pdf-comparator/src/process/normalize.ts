import { PageText } from '../extract/pdfText';
 
export interface NormalizedPage {
  pageNum: number;
  lines: string[];
}
 
export function normalizeDocument(pages: PageText[]): NormalizedPage[] {
  return pages.map(({ pageNum, content }) => {
    const cleaned = content
      .replace(/\s+/g, ' ') // Collapse whitespace
      .replace(/-\s+/g, '') // Remove hyphenated line breaks
      .trim();
 
    const lines = cleaned.split(/(?<=\.)\s+/); // Simple sentence split
    return { pageNum, lines };
  });
}