export function isTableLike(lines: string[]): boolean {
  const rowPattern = /^\s*\|.*\|\s*$/; // crude markdown-like table pattern
  const rowCount = lines.filter(line => rowPattern.test(line)).length;
  return rowCount >= 2;
}