import { SectionDiff } from '../compare/differ';
 
export function formatTxtReport(diffs: SectionDiff[]): string {
  const lines: string[] = [];
 
  for (const diff of diffs) {
    lines.push(`\n=== [${diff.title}] (Page ${diff.pageNum}) ===`);
    lines.push(...diff.changes);
  }
 
  return lines.join('\n');
}