// src/report/reportWriter.ts

import fs from 'fs-extra';

import { SectionDiff } from '../compare/differ';
 
export async function writeTxtReport(diffs: SectionDiff[], outputPath: string) {

  const lines: string[] = [];
 
  for (const diff of diffs) {

    lines.push(`\n=== [${diff.title}] (Page ${diff.pageNum}) ===`);

    lines.push(...diff.changes);

  }
 
  await fs.outputFile(outputPath, lines.join('\n'), 'utf-8');

}

 