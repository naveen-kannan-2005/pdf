import { loadConfig } from './config';
import { extractPdfText } from './extract/pdfText';
import { normalizeDocument } from './process/normalize';
import { segmentDocument } from './process/segment';
import { alignSections } from './compare/align';
import { diffAlignedSections } from './compare/differ';
import { writeTxtReport } from './report/reportWriter';
import * as path from 'path';
 
async function main() {
  const config = loadConfig('config.yaml');
 
  const [oldPdf, newPdf] = await Promise.all([
    extractPdfText(config.oldPath),
    extractPdfText(config.newPath)
  ]);
 
  const [normalizedOld, normalizedNew] = [
    normalizeDocument(oldPdf),
    normalizeDocument(newPdf)
  ];
 
  const [segmentedOld, segmentedNew] = [
    segmentDocument(normalizedOld),
    segmentDocument(normalizedNew)
  ];
 
  const aligned = alignSections(segmentedOld, segmentedNew);
  const sectionDiffs = diffAlignedSections(aligned);
 
  const outPath = path.resolve(config.outputPath || './diff.txt');
  await writeTxtReport(sectionDiffs, outPath);
  console.log(`✅ Comparison complete. Report saved to: ${outPath}`);
}
 
main().catch(err => {
  console.error('❌ Failed:', err);
});