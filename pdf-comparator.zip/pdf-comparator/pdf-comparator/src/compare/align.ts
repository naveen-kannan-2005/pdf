import { Section } from '../process/segment';
 
export interface AlignedSection {
  old?: Section;
  new?: Section;
}
 
export function alignSections(
  oldSections: Section[],
  newSections: Section[]
): AlignedSection[] {
  const aligned: AlignedSection[] = [];
  const usedNew = new Set<number>();
 
  for (const oldSec of oldSections) {
    let bestMatchIdx = -1;
    let maxSim = 0;
 
    for (let i = 0; i < newSections.length; i++) {
      if (usedNew.has(i)) continue;
      const newSec = newSections[i];
      const sim = titleSimilarity(oldSec.title, newSec.title);
      if (sim > maxSim) {
        maxSim = sim;
        bestMatchIdx = i;
      }
    }
 
    if (maxSim > 0.6 && bestMatchIdx !== -1) {
      aligned.push({ old: oldSec, new: newSections[bestMatchIdx] });
      usedNew.add(bestMatchIdx);
    } else {
      aligned.push({ old: oldSec });
    }
  }
 
  newSections.forEach((sec, i) => {
    if (!usedNew.has(i)) aligned.push({ new: sec });
  });
 
  return aligned;
}
 
function titleSimilarity(a: string, b: string): number {
  const [sa, sb] = [a.toLowerCase().split(' '), b.toLowerCase().split(' ')];
  const overlap = sa.filter(word => sb.includes(word)).length;
  return overlap / Math.max(sa.length, sb.length);
}