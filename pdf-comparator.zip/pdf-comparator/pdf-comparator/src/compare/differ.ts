import { AlignedSection } from './align';
import { diffLines } from 'diff';
 
export interface SectionDiff {
  title: string;
  pageNum: number;
  changes: string[];
}
 
export function diffAlignedSections(aligned: AlignedSection[]): SectionDiff[] {
  const results: SectionDiff[] = [];
 
  for (const pair of aligned) {
    const title = pair.new?.title || pair.old?.title || 'Untitled';
    const pageNum = pair.new?.pageNum || pair.old?.pageNum || -1;
 
    const oldLines = pair.old?.lines.join('\n') || '';
    const newLines = pair.new?.lines.join('\n') || '';
    const diffs = diffLines(oldLines, newLines);
 
    const changes = diffs.map(part => {
      if (part.added) return `+ ${part.value.trim()}`;
      if (part.removed) return `- ${part.value.trim()}`;
      return ''; // skip unchanged lines
    }).filter(Boolean);
 
    if (changes.length > 0) {
      results.push({ title, pageNum, changes });
    }
  }
 
  return results;
}