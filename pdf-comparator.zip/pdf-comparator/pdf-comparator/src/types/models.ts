export interface PageText {
  pageNum: number;
  content: string;
}
 
export interface NormalizedPage {
  pageNum: number;
  lines: string[];
}
 
export interface Section {
  id: string;
  title: string;
  pageNum: number;
  lines: string[];
}
 
export interface AlignedSection {
  old?: Section;
  new?: Section;
}
 
export interface SectionDiff {
  title: string;
  pageNum: number;
  changes: string[];
}