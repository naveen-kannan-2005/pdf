import { createWorker } from 'tesseract.js';
import { PageText } from './pdfText';
 
export async function runOCR(images: Buffer[]): Promise<PageText[]> {
  // Create worker (no logger here — added later)
  const worker = await createWorker();
 
  // Assign logger AFTER creation to avoid TS error
  (worker as any).logger = (m: any) => console.log(m);
 
  // These are safe despite TS warnings — cast if needed
  await (worker as any).load();
  await (worker as any).loadLanguage('eng');
  await (worker as any).initialize('eng');
 
  const results: PageText[] = [];
 
  for (let i = 0; i < images.length; i++) {
    const { data: { text } } = await (worker as any).recognize(images[i]);
    results.push({ pageNum: i + 1, content: text });
  }
 
  await (worker as any).terminate();
  return results;
}