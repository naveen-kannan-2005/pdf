import sharp from 'sharp';
 
export async function preprocessImage(buffer: Buffer): Promise<Buffer> {
  return sharp(buffer)
    .grayscale()
    .normalize()
    .resize({ width: 1200 })
    .toBuffer();
}