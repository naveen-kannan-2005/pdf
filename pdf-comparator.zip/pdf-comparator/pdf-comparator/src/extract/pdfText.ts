import fs from 'fs';

import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist/legacy/build/pdf.mjs';
 
(GlobalWorkerOptions as any).disableWorker = true;
 
export interface PageText {

  pageNum: number;

  content: string;

}
 
export async function extractPdfText(filePath: string): Promise<PageText[]> {

  const rawData = new Uint8Array(fs.readFileSync(filePath));

  const pdf = await getDocument({ data: rawData }).promise;
 
  const result: PageText[] = [];
 
  for (let i = 1; i <= pdf.numPages; i++) {

    const page = await pdf.getPage(i);

    const content = await page.getTextContent();
 
    const text = content.items

      .map(item => ('str' in item ? item.str : '')) // type-safe access

      .join(' ');
 
    result.push({ pageNum: i, content: text });

  }
 
  return result;

}

 